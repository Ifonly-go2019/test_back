# coding=utf-8
import sys,os
import time

# 上传数据的代码
def UpLoad(data):
    print(data[0], data[1], data[2], data[3], data)
    time.sleep(2)
    msg = '返回数据：' + 'AAAABBBBCCCCDDDDEEEE'
    return msg