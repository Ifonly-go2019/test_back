# coding=utf-8
#
#
#
#                                                    __----~~~~~~~~~~~------___
#                                   .  .   ~~//====......          __--~ ~~
#                   -.            \_|//     |||\\  ~~~~~~::::... /~
#                ___-==_       _-~o~  \/    |||  \\            _/~~-
#        __---~~~.==~||\=_    -_--~/_-~|-   |\\   \\        _/~
#    _-~~     .=~    |  \\-_    '-~7  /-   /  ||    \      /
#  .~       .~       |   \\ -_    /  /-   /   ||      \   /
# /  ____  /         |     \\ ~-_/  /|- _/   .||       \ /
# |~~    ~~|--~~~~--_ \     ~==-/   | \~--===~~        .\
#          '         ~-|      /|    |-~\~~       __--~~
#                      |-~~-_/ |    |   ~\_   _-~            /\
#                           /  \     \__   \/~                \__
#                       _--~ _/ | .-~~____--~-/                  ~~==.
#                      ((->/~   '.|||' -_|    ~~-/ ,              . _||
#                                 -_     ~\      ~~---l__i__i__i--~~_/
#                                 _-~-__   ~)  \--______________--~~
#                               //.-~~~-~_--~- |-------~~~~~~~~
#                                      //.-~~~--\
#
#
#                        神兽保佑                    代码无BUG!

import sys,os
import time

# 有了这个不会出现程序无响应
import cgitb
cgitb.enable( format = 'text')

from PyQt5 import QtCore, QtGui, uic, QtWidgets

from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *


import Test

# 一个主界面、一个进度条界面
Ui_MainWindow, QtBaseClass_0 = uic.loadUiType(".\GUI\MainWindow.ui")
Ui_Progress, QtBaseClass_1 = uic.loadUiType(".\GUI\Progress.ui")


# *******************************
# **********   主界面
# *******************************
class MyApp(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        Ui_MainWindow.__init__(self)
        self.setupUi(self)
        # 设置标题（在使用了QT Designer 设计好以后可以这么使用）
        self.setWindowTitle('Main')
        # 全屏
        # self.showMaximized()

        # 按钮操作
        self.OpenButton.clicked.connect(self.OpenImage)
        self.ProcessButton.clicked.connect(self.Start_Thread)

        # 连接子进程的信号和槽函数
        self.SingleThread = Single_Thread()
        self.SingleThread.Finish_Signal.connect(self.Finish_Single)

        self.InitButtons_1()
        self.InitButtons_2()

        self.Group1_Click = 0
        self.Group2_Click = 0

    #设置显示图片
    def showpic(self,filename):
        #调用QtGui.QPixmap方法，打开一个图片，存放在变量png中
        png=QPixmap(filename)
        Position = self.pic_label_1.geometry()
        scaredPixmap = png.scaled(Position.width(),
                                  Position.height(),
                                  # aspectRatioMode=Qt.KeepAspectRatio)
                                  aspectRatioMode=Qt.IgnoreAspectRatio)
        self.pic_label_1.setPixmap(scaredPixmap)

    # 关闭主窗口操作
    def closeWindow(self):
        self.close()

    # 关闭窗口的提示
    def closeEvent(self, event):
        box = QtWidgets.QMessageBox()
        Messages_S = "是否退出？"
        Messages_S = Messages_S
        reply = box.warning(self, '退出程序', Messages_S, box.Yes | box.No, box.Yes)
        if reply == box.Yes:
            event.accept()
        else:
            event.ignore()

    # 打开警告弹窗
    def OpenWarningBox(self, Messages_S):
        box = QtWidgets.QMessageBox()
        Messages_S = Messages_S
        box.warning(self, '警告', Messages_S, box.Ok)

    # 打开图片
    def OpenImage(self):
        filenames = QFileDialog.getOpenFileName(self, "Choose Image", "", "jpg files(*.jpg);;png files(*.png)")
        if len(filenames[0]) > 0:
            self.filename = filenames[0]
            self.showpic(self.filename)

    # 开始识别
    def Start_Thread(self):
        self.OUTPUT.clear()
        self.SingleThread.start()
        # 必须放到最后一条，因为底下的代码不会执行
        Progress_window.exec_()

    # 结束识别后需要显示的图片和结果
    def Finish_Single(self,Result):
        # 关闭进度条窗口
        Progress_window.close()
        self.OUTPUT.append(Result)

    # 单选框
    def InitButtons_1(self):
        self.Group1 = QButtonGroup(self)
        self.Group1.addButton(self.radioButton_1,1)
        self.Group1.addButton(self.radioButton_2,2)
        self.Group1.addButton(self.radioButton_3,3)


        self.Group1.buttonClicked.connect(self.Group1Clicked)

    def Group1Clicked(self):
        sender = self.sender()
        if sender == self.Group1:
            if self.Group1.checkedId() >= 1 and self.Group1.checkedId() <= 3:
                self.Group1_Click = self.Group1.checkedId()


    # 单选框
    def InitButtons_2(self):
        self.Group2 = QButtonGroup(self)
        self.Group2.addButton(self.radioButton_4,1)
        self.Group2.addButton(self.radioButton_5,2)


        self.Group2.buttonClicked.connect(self.Group2Clicked)

    def Group2Clicked(self):
        sender = self.sender()
        if sender == self.Group2:
            if self.Group2.checkedId() >= 1 and self.Group1.checkedId() <= 2:
                self.Group2_Click = self.Group2.checkedId()


# *******************************
# **********   进度条窗口
# *******************************
class Progress_Dialog(QtWidgets.QDialog, Ui_Progress):
    def __init__(self):
        QtWidgets.QDialog.__init__(self)
        Ui_Progress.__init__(self)
        self.setupUi(self)
        # 设置标题（在使用了QT Designer 设计好以后可以这么使用）
        # 无边框效果以及窗口前置效果
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        self.setWindowOpacity(0.9)

    # **********   关闭窗口的提示
    def closeEvent(self, event):
        event.accept()


# *************************************
# ********** 多线程任务
# *************************************
class Single_Thread(QThread):
    # 结束信号
    Finish_Signal = pyqtSignal(str)
    def __init__(self, parent=None):
        super(Single_Thread, self).__init__(parent)

    def run(self):
        # 运行你的算法处理程序
        # 运行你的算法处理程序
        # 运行你的算法处理程序
        # 运行你的算法处理程序
        # 运行你的算法处理程序
        # 运行你的算法处理程序
        # 例如：
        #
        data = []
        data.append(window.lineEdit_1.text())
        data.append(window.lineEdit_2.text())
        data.append(window.lineEdit_3.text())
        data.append(window.lineEdit_4.text())

        data.append(window.Group1_Click)
        data.append(window.Group2_Click)

        data.append(window.textEdit_2.toPlainText())
        data.append(window.textEdit_3.toPlainText())
        data.append(window.textEdit_4.toPlainText())
        data.append(window.textEdit_5.toPlainText())
        data.append(window.textEdit_6.toPlainText())
        data.append(window.textEdit_7.toPlainText())
        data.append(window.textEdit_8.toPlainText())
        data.append(window.textEdit_9.toPlainText())
        data.append(window.textEdit_10.toPlainText())
        data.append(window.textEdit_11.toPlainText())

        ret = Test.UpLoad(data)
        # 将结果发送给主界面
        self.Finish_Signal.emit(ret)


# 这段主程序创建了一个新的 Qt Gui 应用。，每个 QT 应用都可以通过命令行进行配置，所以必须传入sys.argv 参数。
if __name__ == "__main__":

    app = QtWidgets.QApplication(sys.argv)
    Progress_window = Progress_Dialog()
    window = MyApp()
    window.show()

    sys.exit(app.exec_())
